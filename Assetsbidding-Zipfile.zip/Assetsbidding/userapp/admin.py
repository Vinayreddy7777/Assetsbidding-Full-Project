from django.contrib import admin
from .models import UserRegisterModel
# Register your models here.

admin.site.register(UserRegisterModel)
